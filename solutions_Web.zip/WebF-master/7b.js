var express=require('express')
var mongoclient=require('mongodb').MongoClient
var bodyparser=require('body-parser')
var app=express()
var urlencoded=bodyparser.urlencoded({extended:false})
app.use(bodyparser.json())
app.use(express.static('public'));

mongoclient.connect("mongodb://127.0.0.1/student",function(err,db){
	if(err){
		console.log(err);
	}
    app.get('/',function(req,res){
        res.sendFile(__dirname+"/public/"+"index7.html")
    });
    app.get('/insert',(req,res)=>{
        res.sendFile(__dirname+"/public/"+"insert7.html")
    });
    
    app.post('/process_post',function(req,res){
        console.log('process')
        req.body.Message="Sending Data";
        console.log(req.body);
        var grade=req.body.grade
        var name=req.body.name
        db.collection('s').insert({name:name,grade:grade});
        res.send("Student Data Record --->  "+JSON.stringify(req.body))
    });
    app.get('/display',function(req,res){
        db.collection('s').find({grade:'S'}).toArray(function(err,data){
                data.forEach(element => {
                    res.send(element);
                });
        })
    })
    app.listen(5000);
});

//public/

//public/insert7.html

